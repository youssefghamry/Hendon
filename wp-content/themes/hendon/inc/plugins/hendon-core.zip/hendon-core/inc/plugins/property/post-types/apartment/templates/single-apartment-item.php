<?php

get_header();

hendon_core_template_part( 'plugins/property/post-types/apartment', 'templates/content' );

get_footer();