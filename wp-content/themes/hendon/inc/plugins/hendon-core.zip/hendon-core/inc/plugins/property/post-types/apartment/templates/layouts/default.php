<article <?php post_class( 'qodef-apartment-item qodef-e' ); ?>>
    <div class="qodef-e-inner">
        <div class="qodef-e-content">
            <?php
            // Get item content part
            the_content();

            ?>
        </div>
    </div>
</article>