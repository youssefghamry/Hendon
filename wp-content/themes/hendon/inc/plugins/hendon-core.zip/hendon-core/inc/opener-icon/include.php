<?php

include_once HENDON_CORE_INC_PATH . '/opener-icon/helper.php';