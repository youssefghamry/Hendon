<?php

include_once HENDON_CORE_INC_PATH . '/left-fixed-area/helper.php';