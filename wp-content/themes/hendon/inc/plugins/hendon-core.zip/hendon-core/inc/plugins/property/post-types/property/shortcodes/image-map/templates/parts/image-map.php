<div class="qodef-image-map-holder" <?php qode_framework_inline_attr( $image_map_shortcode_attr, 'data-options' ); ?>>
    <?php echo do_shortcode($image_map_shortcode); ?>
    <div class="qodef-image-map-holder-overlay"></div>
</div>