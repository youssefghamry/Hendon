<a id="qodef-back-to-top" href="#">
    <span class="qodef-back-to-top-icon">
    <svg version="1.1" xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
        width="44px" height="44px" viewBox="0 0 44 44" enable-background="new 0 0 44 44" xml:space="preserve">
        <rect x="1.484" y="1.531" fill="none" stroke="#5B5B5B" stroke-miterlimit="10" width="41" height="41"/>
        <rect x="1.484" y="1.531" fill="none" stroke="#838383" stroke-miterlimit="10" width="41" height="41"/>
        <polyline fill="none" stroke="#5B5B5B" stroke-miterlimit="10" points="16.572,25.293 21.984,18.77 27.397,25.293 "/>
        <polyline fill="none" stroke="#838383" stroke-miterlimit="10" points="16.572,25.293 21.984,18.77 27.397,25.293 "/>
    </svg>
    </span>
</a>