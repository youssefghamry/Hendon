<div id="qodef-content-bottom">
    <?php dynamic_sidebar( $content_bottom_area_sidebar ); ?>
</div>