<?php

include_once HENDON_CORE_INC_PATH . '/icons/simple-line-icons/simple-line-icons.php';