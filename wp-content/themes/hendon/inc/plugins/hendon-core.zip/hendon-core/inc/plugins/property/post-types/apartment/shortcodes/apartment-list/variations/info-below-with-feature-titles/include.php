<?php

include_once HENDON_CORE_PLUGINS_PATH . '/property/post-types/apartment/shortcodes/apartment-list/variations/info-below-with-feature-titles/info-below-with-feature-titles.php';