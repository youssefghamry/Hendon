<?php

include_once HENDON_CORE_PLUGINS_PATH . '/instagram/shortcodes/instagram-list/instagram-list.php';