<div class="qodef-e-pai-content-section-holder">
    <?php echo hendon_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-advanced-info', 'templates/parts/content-feature-items', '', $params ); ?>

    <?php echo hendon_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-advanced-info', 'templates/parts/content-description', '', $params ); ?>

    <?php echo hendon_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-advanced-info', 'templates/parts/content-button', '', $params ); ?>
</div>