<?php

include_once HENDON_CORE_INC_PATH . '/age-verification/helper.php';
include_once HENDON_CORE_INC_PATH . '/age-verification/dashboard/admin/age-verification-options.php';
include_once HENDON_CORE_INC_PATH . '/age-verification/dashboard/meta-box/age-verification-meta-box.php';