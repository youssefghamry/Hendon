<?php

include_once HENDON_CORE_PLUGINS_PATH . '/contact-form-7/contact-form-7.php';