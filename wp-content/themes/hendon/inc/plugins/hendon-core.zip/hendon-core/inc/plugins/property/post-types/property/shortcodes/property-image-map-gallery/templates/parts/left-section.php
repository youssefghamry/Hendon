<div class="qodef-img-section qodef-img-holder-inner active">

    <?php echo hendon_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-image-map-gallery', 'templates/parts/main-slider', '', $params ); ?>

    <?php echo hendon_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-image-map-gallery', 'templates/parts/thumbnail-slider', '', $params ); ?>

</div>

<?php echo hendon_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-image-map-gallery', 'templates/parts/video', '', $params ); ?>

<?php echo hendon_core_get_template_part( 'plugins/property/post-types/property/shortcodes/property-image-map-gallery', 'templates/parts/video', '360', $params ); ?>


